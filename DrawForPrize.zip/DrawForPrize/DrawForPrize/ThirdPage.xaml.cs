﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace DrawForPrize
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class ThirdPage : Page
    {
        private object storageFolder;

        public ThirdPage()
        {
            this.InitializeComponent();
            Text.IsEnabled = false; 
        }
        private async void processOne_ClickAsync(object sender, RoutedEventArgs e)
        {
            StorageFolder storageFolder = ApplicationData.Current.LocalFolder;
            if (await storageFolder.TryGetItemAsync("CustomerData.txt") != null)
            {
                StorageFile infoFile = await storageFolder.CreateFileAsync("CustomerData.txt", CreationCollisionOption.OpenIfExists);
                string codes = await FileIO.ReadTextAsync(infoFile);
                char[] delimiterChars = { '\n' };
                string[] codesInLines = codes.Split(delimiterChars);
                Text.Text = codesInLines[codesInLines.Length - 1];
            }
        }

        private async void processTen_Click(object sender, RoutedEventArgs e)
        {
            StorageFolder storageFolder = ApplicationData.Current.LocalFolder;
            if (await storageFolder.TryGetItemAsync("CustomerData.txt") != null)
            {
                StorageFile infoFile = await storageFolder.CreateFileAsync("CustomerData.txt",CreationCollisionOption.OpenIfExists);
                string codes = await FileIO.ReadTextAsync(infoFile);
                char[] delimiterChars = { '\n' };
                string[] codesInLines = codes.Split(delimiterChars);
                int max;
                if (codesInLines.Length < 11) 
                    max = codesInLines.Length;
                else
                    max = 10;
                string textForText = "";
                for (int i=0;i < max; i++) { 
                    textForText += codesInLines[i] + "\n";
                }
             Text.Text = textForText;
            }
        }
    }
}
