﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text.RegularExpressions;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace DrawForPrize
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class SecondPage : Page
    {
        public SecondPage()
        {
            this.InitializeComponent();
        }
      
        public void copyCode(String code)
        {

        }
        private async void processCode_Click(object sender, RoutedEventArgs e)
        {
            if (serialNumber.Text != "")
            {
                StorageFolder storageFolder = ApplicationData.Current.LocalFolder;
                Boolean isThere = false;
                String serialCode = "";
                if (await storageFolder.TryGetItemAsync("Codes.txt") != null)
                {
                    StorageFile ticketsFile = await storageFolder.CreateFileAsync("Codes.txt",CreationCollisionOption.OpenIfExists);
                    string codes = await FileIO.ReadTextAsync(ticketsFile);
                    char[] delimiterChars = { '\n' };
                    string[] codesInLines = codes.Split(delimiterChars);
                    codes = "";
                    for (int i = 0; i < codesInLines.Length; i++)
                    {
                        if (serialNumber.Text
                            != codesInLines[i])
                        {
                            if (i != codesInLines.Length - 1)
                                codes += codesInLines[i] + "\n";
                            else
                                codes += codesInLines[i];
                        }
                        else
                        {
                            isThere = true;
                            serialCode = codesInLines[i];
                        }
                    }
                    await FileIO.WriteTextAsync(ticketsFile, codes);
                }
                if (isThere == false)
                {
                    DisplayLocationPromptDialog("Serial number");
                }
                else
                {
                    String name = validateName();
                    String surname = validateSurname();
                    String email = validateEmail();
                    String phoneNumber = validatePhoneNumber();
                    if (name == "" || surname == "" || email == "" || phoneNumber == ""){
                        if (name == "") DisplayLocationPromptDialog("Name");
                        else if (surname == "") DisplayLocationPromptDialog("Surname");
                        else if (email == "") DisplayLocationPromptDialog("Email");
                        else if (phoneNumber == "") DisplayLocationPromptDialog("Phone Number");

                        if (await storageFolder.TryGetItemAsync("Codes.txt") != null)
                        {
                            StorageFile ticketsFile = await storageFolder.CreateFileAsync("Codes.txt", CreationCollisionOption.OpenIfExists);
                            string codes = await FileIO.ReadTextAsync(ticketsFile);
                            codes += "\n" + serialCode;
                            await FileIO.WriteTextAsync(ticketsFile, codes);
                        }
                    }
                    else { 
                        StorageFolder customerData = ApplicationData.Current.LocalFolder;
                        if (await storageFolder.TryGetItemAsync("CustomerData.txt") == null)
                        {
                            StorageFile infoFile = await storageFolder.CreateFileAsync("CustomerData.txt");
                            String allDataValidated = serialCode + " "  + name + " " + surname + " " + email + " " + phoneNumber;
                            await FileIO.WriteTextAsync(infoFile, allDataValidated);
                        }
                        else if (await storageFolder.TryGetItemAsync("CustomerData.txt") != null)
                        {
                            StorageFile infoFile = await storageFolder.CreateFileAsync("CustomerData.txt",CreationCollisionOption.OpenIfExists);
                            String codes = await FileIO.ReadTextAsync(infoFile);
                            String allDataValidated = serialCode + " " + name + " " + surname + " " + phoneNumber + " " + email;
                            codes += "\n" + allDataValidated; 
                            await FileIO.WriteTextAsync(infoFile, codes);
                        }
                        processCode.IsEnabled = false;
                    }
                }
            }
        }
        public async void DisplayLocationPromptDialog(String what)
        {
            ContentDialog locationPromptDialog = new ContentDialog
            {
                Title = "Warning!",
                Content = what + " is wrong.",
                CloseButtonText = "Cancle"
            };
            ContentDialogResult result = await locationPromptDialog.ShowAsync();
        }
        public String validateName() {
            String isItGood;
            if (!Regex.Match(Name.Text, "^[A-Z][a-zA-Z]*$").Success)
                isItGood = "";
            else
                isItGood = Name.Text;
            return isItGood; 
        }
        public String validateSurname()
        {
            String isItGood;
            if (!Regex.Match(Surname.Text, "^[A-Z][a-zA-Z]*$").Success)
                isItGood = "";
            else
                isItGood = Surname.Text;
            return isItGood;
        }
        public String validateEmail()
        {
            String isItGood;
            if (!Regex.Match(Email.Text, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z").Success)
                isItGood = "";
            else
                isItGood = Email.Text;
            return isItGood;
        }
        public String validatePhoneNumber()
        {
            String isItGood;
            if (!Regex.Match(PhoneNumber.Text, @"^(\+[0-9]{10})$").Success)
                isItGood = "";
            else
                isItGood = PhoneNumber.Text;
            return isItGood;
        }

        private void AppBarButton_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(ThirdPage));
        }
    }
}
