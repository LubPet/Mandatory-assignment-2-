﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage;
using Windows.UI.Xaml.Controls;

namespace DrawForPrize
{
    class CreateCodes
    {
        public async void generateCodesAsync()
        {
            StorageFolder storageFolder = ApplicationData.Current.LocalFolder;
            if (await storageFolder.TryGetItemAsync("Codes.txt") == null)
            {
                StorageFile ticketsFile = await storageFolder.CreateFileAsync("Codes.txt",CreationCollisionOption.ReplaceExisting);
                string completeText = "";
                Random rnd = new Random();

                for (int i = 0; i < 100; i++)
                {
                    string text = "";
                    string[] consonants = { "b", "c", "d", "f", "g", "h", "j", "k", "l", "m", "n", "p", "q", "r", "s", "t", "v", "w", "x", "y", "z" };
                    string[] vowels = { "a", "e", "i", "o", "u" };
                    string[] numbers = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", };

                    int jump = rnd.Next(1, 6);
                    for (int j = jump; j < consonants.Length;)
                    {
                        text += consonants[j];
                        jump = rnd.Next(1, 6);
                        j = j + jump;
                    }
                    jump = rnd.Next(1, 3);
                    for (int j = jump; j < vowels.Length;)
                    {
                        text += vowels[j];
                        jump = rnd.Next(1, 3);
                        j = j + jump;
                    }
                    jump = rnd.Next(1, 3);
                    for (int j = jump; j < numbers.Length;)
                    {
                        jump = rnd.Next(2, 4);
                        text += numbers[j];
                        j = j + jump;
                    }
                    if (i != 99)
                        completeText += text + "\n";
                    else
                        completeText += text;
                }
                await FileIO.WriteTextAsync(ticketsFile, completeText);
            }
        }
    }
}
